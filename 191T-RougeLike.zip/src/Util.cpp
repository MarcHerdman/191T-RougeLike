#include "Util.h"

int defaultScreenSizeX = 1920;
int defaultScreenSizeY = 1080;
