#include "Button.h"

Button::Button()
{
    //ctor
}

Button::~Button()
{
    //dtor
}
