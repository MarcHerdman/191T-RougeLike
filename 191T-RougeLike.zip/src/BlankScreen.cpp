#include "BlankScreen.h"

BlankScreen::BlankScreen(std::stack<Scene*>*)
{

}

BlankScreen::~BlankScreen()
{
    //dtor
}

void BlankScreen::Init(int x, int y)
{

}

void BlankScreen::Draw()
{

}

void BlankScreen::Action(std::string action)
{

}

void BlankScreen::ScreenResized(int screenWidth, int screenHeight)
{

}
