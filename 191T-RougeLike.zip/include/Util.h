#ifndef UTIL_H
#define UTIL_H

extern int defaultScreenSizeX;
extern int defaultScreenSizeY;

#endif // UTIL_H
